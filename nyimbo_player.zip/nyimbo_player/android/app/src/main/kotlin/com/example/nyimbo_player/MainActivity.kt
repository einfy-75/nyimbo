package com.example.nyimbo_player

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
