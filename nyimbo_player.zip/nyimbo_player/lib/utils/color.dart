

// import 'package:flutter/material.dart';

// class AppColor {
  
//   static final Color color; 

// }